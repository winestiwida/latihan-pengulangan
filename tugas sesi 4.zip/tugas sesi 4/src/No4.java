public class No4 {
    public static void main(String[] args) {
        int[][] numbers = {
            {4, 4, 16}, 
            {4, 5, 20}, 
            {4, 6, 24}, 
            {5, 5, 25}, 
            {5, 6, 30}, 
            {5, 7, 35}, 
            {6, 6, 36}, 
            {6, 7, 42}, 
            {6, 8, 48},
        };
        
        for (int[] row : numbers) {
            System.out.printf("%d x %d = %d\n", row[0], row[1], row[2]);
        }
    }
}
