public class No5 {
    public static void main(String[] args) {
        String pattern = "B C B C\nC B C B\nB C B C\nC B C B";
        System.out.println(pattern);
    }
}
