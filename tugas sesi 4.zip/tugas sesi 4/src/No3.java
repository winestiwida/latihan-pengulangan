public class No3 {
    public static void main(String[] args) {
        int[] numbers = {0, 1, 1, 2, 3, 5, 8, 13};
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i]+ " ");
        }
    }
}

